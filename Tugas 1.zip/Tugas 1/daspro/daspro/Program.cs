﻿// HelloWorld! program
using System;

namespace HelloWorld
{
    class Hello
    {
        static void Main(String[] args)
        {
            Console.WriteLine("Anda adalah agen rahasia yang bertugas mendapatkan data dari server");
            Console.WriteLine("Akses ke server membutuhkan password yang tidak diketahui");
        }
    }
}