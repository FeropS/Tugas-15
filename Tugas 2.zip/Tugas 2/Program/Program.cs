﻿/* Hello World! program
Nama : Fadil Fajar
NIM : 2207111388
Kelas : Teknik Informatika - A
*/
using System;

namespace daspro
{
    class Program
    {
        //Main Method
        static void Main(String[] args)
        {
            //Deklarasi Variabel
            int codeA;
            int codeB;
            int codeC;
            int jumlahKode;
            String tebakanA;
            String tebakanB;
            String tebakanC;


            int hasilTambah;
            int hasilKali;
            
            //Inisialisasi Variabel
            codeA = 1;
            codeB = 2;
            codeC = 3;

            jumlahKode = 3;

            //Operasi Aritmatika
            hasilTambah = codeA+codeB+codeC;
            hasilKali = codeA*codeB*codeC;

            //Intro
            Console.WriteLine("Anda adalah seorang agen rahasia mendapatkan data dari server");
            Console.WriteLine("Akses ke server membutuhkan password yang tidak diketahui...");
            Console.WriteLine("- Password terdiri dari "+jumlahKode+" angka");
            Console.WriteLine("- Jika ditambahkan maka hasilnya "+hasilTambah);
            Console.WriteLine("- Jika dikalikan maka hasilnya "+hasilKali);

            //Input User
            Console.Write("Enter Kode 1: ");
            tebakanA = Console.ReadLine();
            Console.Write("Enter Kode 2: ");
            tebakanB = Console.ReadLine();
            Console.Write("Enter Kode 3: ");
            tebakanC = Console.ReadLine();


            Console.WriteLine("Tebakan Anda "+tebakanA+" "+tebakanB+" "+tebakanC+" ?");

            if(tebakanA == codeA.ToString() && tebakanB == codeB.ToString() && tebakanB == codeB.ToString())
            {
                Console.WriteLine("Tebakan Anda Benar");
            }else{
                Console.WriteLine("Tebakan Anda SALAH");
            }
        }
    }
}