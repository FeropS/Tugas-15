﻿/*
Nama : Fadil Fajar
NIM : 2207111388
Kelas : Teknik Informatika - A
*/
using System;

namespace DADU
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Selamat Datang Dalam Game Dadu");
            Console.WriteLine("Disini Anda Akan Bermain Bersama Computer ");
            Console.WriteLine("Cara Mainnya Cukup Mudah ");
            Console.WriteLine("Nilai Lebih Besar yang Akan Menang ");
            Console.WriteLine("Apakah Anda atau Computer");
            Console.WriteLine();
            Console.ReadKey();
            int userNum;
            int Ronde = 1;
            int computerNum;
            int pointUser = 0;
            int pointComputer = 0;

            Random random = new Random();

            for(int i = 0; i < 10; i++)
        {
            Console.WriteLine("Ronde "+Ronde);
            Ronde++;
            userNum = random.Next(1, 7);
            Console.WriteLine("Nilai Anda: "+userNum+" ");
            //System.Threading.Thread.Sleep(10000);
            computerNum = random.Next(1, 7);
            Console.WriteLine("Nilai Computer: "+computerNum+" ");
            //Console.ReadKey();

            if(userNum > computerNum){
                pointUser++;
                Console.WriteLine("Anda Menang Ronde ini");
            }else if(userNum < computerNum){
                pointComputer++;
                Console.WriteLine("Anda Kalah  DiRound Ini");
            }else
            {
                Console.WriteLine("Selamat Nilainya SERI");
            }
            //Console.WriteLine();
            Console.WriteLine("YOUR SCORE : "+pointUser);
            Console.WriteLine("COMPUTER SCORE: "+pointComputer);
            Console.WriteLine();
            Console.ReadKey();
            }
        if(pointUser > pointComputer){
            Console.WriteLine("You Are The Winner ");
        }else if(pointUser < pointComputer){
            Console.WriteLine("You Are The Loser");
        }else{
            Console.WriteLine("The Point Is Draw");

        }
        Console.ReadKey();
        }
    }
    
}